import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QAction, QMenu


class MenuExample(QMainWindow):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setWindowTitle("Пример меню с сортировкой")
        self.setGeometry(100, 100, 400, 300)

        # Создаем меню "Файл"
        main_menu = self.menuBar()
        file_menu = main_menu.addMenu("Файл")

        # Создаем QAction и добавляем в меню "Файл"
        action_exit = QAction("Выход", self)
        file_menu.addAction(action_exit)
        action_exit.triggered.connect(self.close)

        # Создаем меню "Тест"
        test_menu = main_menu.addMenu("Тест")

        # Генерируем 10 пунктов в меню "Тест"
        test_actions = []
        for i in range(10, 0, -1):
            action = QAction(f"Пункт {i}", self)
            test_actions.append(action)

        # Сортируем действия по алфавиту
        test_actions.sort(key=lambda x: x.text())

        # Добавляем отсортированные действия в меню "Тест"
        for action in test_actions:
            test_menu.addAction(action)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MenuExample()
    window.show()
    sys.exit(app.exec_())
